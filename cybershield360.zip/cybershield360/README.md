# CyberShield 360
Setup (Windows, VS Code terminal):
    python -m venv venv
    venv\Scripts\activate
    pip install -r requirements.txt
    python app.py
Open http://127.0.0.1:5000
