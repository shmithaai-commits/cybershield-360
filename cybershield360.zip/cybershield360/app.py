from flask import Flask, render_template

app = Flask(__name__)

MODULES = [
    {"slug": "hunting",   "name": "Threat Hunting",       "unit": "Unit II",
     "desc": "Logs, IoCs, SIEM-style rules and attacker trends.",
     "todo": ["Upload sample logs", "IoC search", "Hunt rules (e.g. 5 failed logins in 1 min)", "Attacker origin map"]},
    {"slug": "soc",       "name": "CTI-SOC Center",       "unit": "Unit III",
     "desc": "Incident workflow with CTI enrichment and sharing.",
     "todo": ["Incident board", "IoC enrichment", "Risk calculator", "TAXII-style feed sharing"]},
    {"slug": "forensics", "name": "Law & Forensics",      "unit": "Unit IV",
     "desc": "Cybercrime scenarios mapped to laws and evidence steps.",
     "todo": ["Scenario wizard", "IT Act / IPC sections", "Evidence checklist", "Case summary download"]},
    {"slug": "reports",   "name": "Analysis & Reporting", "unit": "Unit V",
     "desc": "Risk scores, tags, analyst approval and reports.",
     "todo": ["Risk-score engine", "Tagging", "Analyst approval", "PDF report", "DevSecOps gate demo"]},
]

TREND = {"labels": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
         "phishing": [12, 18, 15, 22, 30, 19, 14],
         "bruteforce": [40, 35, 52, 48, 61, 44, 38],
         "malware": [5, 7, 4, 9, 12, 8, 6]}

ALERTS = [
    {"time": "10:42", "severity": "High",   "type": "Brute force",  "source": "185.220.101.4",    "asset": "web-server-01", "status": "Open"},
    {"time": "10:15", "severity": "High",   "type": "Phishing URL", "source": "secure-bank-login.xyz", "asset": "mail-gateway", "status": "Investigating"},
    {"time": "09:58", "severity": "Medium", "type": "Port scan",    "source": "45.155.205.233",   "asset": "db-server-02",  "status": "Open"},
    {"time": "09:30", "severity": "Low",    "type": "Bad hash",     "source": "e99a18c4...",      "asset": "laptop-17",     "status": "Closed"},
]

KPIS = [("Active alerts", 14), ("IoCs tracked", 1286), ("Open incidents", 5), ("Critical assets at risk", 3)]

@app.context_processor
def inject():
    return {"modules": MODULES, "app_name": "CyberShield 360"}

@app.route("/")
def dashboard():
    return render_template("dashboard.html", kpis=KPIS, alerts=ALERTS, trend=TREND)

@app.route("/<slug>")
def module(slug):
    m = next((x for x in MODULES if x["slug"] == slug), None)
    if not m:
        return render_template("module.html", m=None), 404
    return render_template("module.html", m=m)

if __name__ == "__main__":
    app.run(debug=True)
